# SynthSoup wavetables

The TABLE engine's 16 tables (BASIC, PWM, SYNC, VOCAL, ORGAN, BUILD, FM, FOLD, RESO, CHAOS, COMB, PSYCH, HOLLW, STEPS,
GROWL, NOISE) as Serum-format wavetables: 32-bit float mono WAVs of 16 frames × 2048 samples, with the `clm ` chunk
(`<!>2048 ...`) that Serum, Serum 2, Vital and other wavetable synths read. They are the frames the FM-1 plays (each
band-limited to 64 harmonics), so a sound sketched on the FM-1 can be finished in the computer.

The other way round: the web editor's Samples tab turns a wavetable .wav from those synths (including the tables that
come with them, from your own computer) into a table for the FM-1: drop it on a USR slot, then pick TABLE, TABL USR1–3.

Rebuild: `cc -O2 -w -Ibuild/gen -Ifirmware/src -o /tmp/table_test tests/table_test.c -lm && /tmp/table_test --dump /tmp/wt
&& python3 tools/gen_serum_tables.py /tmp/wt`.
